package Client;

import ocsf.client.*;
import common.*;
import gui.DisplayRequiermentController;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

import Entity.Requierment;

public class IcmClient extends AbstractClient {
	IcmIF clientUI;

	public IcmClient(String host, int port, IcmIF clientUI) throws IOException {
		super(host, port); // Call the superclass constructor
		this.clientUI = clientUI;
		openConnection();
	}

	//Here we receive date from the server
	public void handleMessageFromServer(Object msg) {
		if (msg.getClass() == ArrayList.class) {//checking if we receive an array list, then we cast it to Requirement class
			ArrayList<Requierment> requierments = new ArrayList<Requierment>();
			@SuppressWarnings("unchecked")
			List<ArrayList<String>> requiermentsListIds = (ArrayList<ArrayList<String>>) msg;
			for (int i = 0; i < requiermentsListIds.size(); i++)
				requierments.add(Requierment.fromArrayToClass(requiermentsListIds.get(i)));
			clientUI.setRequierments(requierments);
		}
	}

	//Sending date to the server
	public void handleMessageFromClientUI(String message) {
		try {
			sendToServer(message);
		} catch (IOException e) {
			DisplayRequiermentController.showMessage("Error", "Could not send message to server.  Terminating client.");
			quit();
		}
	}

	/**
	 * This method terminates the client.
	 */
	public void quit() {
		try {
			closeConnection();
		} catch (IOException e) {
		}
		System.exit(0);
	}
}
