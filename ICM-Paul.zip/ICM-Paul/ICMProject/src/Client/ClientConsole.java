package Client;
import java.io.*;
import java.util.ArrayList;

import Entity.Requierment;
import common.*;
import gui.DisplayRequiermentController;

public class ClientConsole implements IcmIF {

	final public static int DEFAULT_PORT = 5555;
	
	public static IcmClient client;
	public static ClientConsole clientConsole;
	private static DisplayRequiermentController DRC;

	public static void main(String[] args) {
		try {
			clientInit(args[0], Integer.parseInt(args[1]));
			
		}catch(Exception c) {
			try {
				clientInit(args[0], DEFAULT_PORT);
				
			}catch(Exception d) {
				clientInit("localhost", DEFAULT_PORT);

			}
		}
		
		DRC = new DisplayRequiermentController();
		DRC.launchThis();

	}

	public static void clientInit(String host, int port) {
		clientConsole = new ClientConsole();
		try {
			client = new IcmClient(host, port, clientConsole);
		} catch (IOException exception) {
			System.out.println("Error: Can't setup connection!" + " Terminating client.");
			System.exit(1);
		}
	}


	//This function request from the server to update requirement to new status by id
	public static boolean updateRequierment(String id, String status) {
		try {
			if (!client.isConnected())
				client.openConnection();
			client.sendToServer("doupdate#"+id + "#" + status);//the server receive the id#status, the # is break between the id and status
			return true;
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
	}

	//The server send to client the requirements table, and the client use this function to set the requirements
	@Override
	public void setRequierments(ArrayList<Requierment> requiermentsList) {
		DisplayRequiermentController.setRequiermentList(requiermentsList);
	}

}
