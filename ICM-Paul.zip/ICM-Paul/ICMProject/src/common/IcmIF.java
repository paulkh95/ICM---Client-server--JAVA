package common;

import java.util.ArrayList;
import Entity.Requierment;

public interface IcmIF 
{
	public void setRequierments(ArrayList<Requierment> requiermentsList);
}
