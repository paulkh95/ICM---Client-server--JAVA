package Server;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import Entity.Requierment;

public class mysqlConnection {
	private static Connection conn;
	private static boolean connected = false;

	public static Connection connection() {
		return conn;
	}

	public static boolean isConnected() {
		return connected;
	}

	public static void connect() {
		if (connected == false) {
			try {
				Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
				System.out.println("Driver definition succeed");

			} catch (Exception ex) {
				/* handle the error */
				System.out.println("Driver definition failed");
			}

			try {
				conn = DriverManager.getConnection("jdbc:mysql://localhost/icm?serverTimezone=IST", "root", "Aa123456");
				System.out.println("SQL connection succeed");
				connected = true;

			} catch (SQLException ex) {/* handle any errors */
				System.out.println("SQLException: " + ex.getMessage());
				System.out.println("SQLState: " + ex.getSQLState());
				System.out.println("VendorError: " + ex.getErrorCode());
			}
		}
	}

	public static void disConnect() {
		try {
			conn.close();
			conn = null;
			connected = false;
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	//This function gets all requiments from db
	public static ArrayList<Requierment> getAllRequierments() {

		ArrayList<Requierment> requiermentsList = new ArrayList<Requierment>();
		try {

			Statement stmt = conn.createStatement();
			ResultSet rs;

			rs = stmt.executeQuery("SELECT * FROM requirement");
			while (rs.next()) {
				requiermentsList.add(new Requierment(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4),
						rs.getString(5), rs.getString(6), rs.getString(7)));
			}
			// conn.close();
		} catch (Exception e) {
			System.err.println("Got an exception! ");
			System.err.println(e.getMessage());
		}

		return requiermentsList;
	}
	//Updating requirement in database
	public static boolean updateRequierment(String id, String status) {
		try {

			Statement stmt = conn.createStatement();

			stmt.executeUpdate("UPDATE requirement SET Status='" + status + "'  WHERE id_number='" + id + "'");

		} catch (Exception e) {
			System.err.println("Got an exception! ");
			System.err.println(e.getMessage());
			return false;
		}

		System.out.print("Fuck You All:");
		System.out.print("Requierment updated:" + id);
		return true;
	}

}
