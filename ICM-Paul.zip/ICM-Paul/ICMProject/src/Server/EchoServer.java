package Server;

import java.io.*;
import java.util.ArrayList;

import Entity.Requierment;
import ocsf.server.*;

public class EchoServer extends AbstractServer {

	final public static int DEFAULT_PORT = 5555;

	public EchoServer(int port) {
		super(port);
	}

	//Here we handling messages from the client
	public void handleMessageFromClient(Object msg, ConnectionToClient client) {
		String[] m = msg.toString().split("#");
		
		if (m[0].equals("doupdate")) {//Check if requesting an update
			updateRequierment(m[1], m[2]);//Update the requirement
		}
		else if(msg.toString().equals("getAllRequirements")) {//Check if requesting all requirements
		ArrayList<Requierment> requiermentsList = getAllRequierments();//getting all requirements and casting to array to send to the client
		ArrayList<ArrayList<String>> requiermentsListIds = new ArrayList<ArrayList<String>>();
		for (int i = 0; i < requiermentsList.size(); i++)
			requiermentsListIds.add(requiermentsList.get(i).toArrayString());
		try {
			client.sendToClient(requiermentsListIds);
		} catch (IOException e) {
			e.printStackTrace();
		}
		}
	}

	protected void serverStarted() {
		System.out.println("Server listening for connections on port " + getPort());
	}

	protected void serverStopped() {
		System.out.println("Server has stopped listening for connections.");
	}

	public static void main(String[] args) {
		int port = 0; // Port to listen on

		try {
			port = Integer.parseInt(args[0]); // Get port from command line
		} catch (Throwable t) {
			port = DEFAULT_PORT; // Set port to 5555
		}

		EchoServer sv = new EchoServer(port);

		try {
			sv.listen(); // Start listening for connections
		} catch (Exception ex) {
			System.out.println("ERROR - Could not listen for clients!");
		}
	}

	public static ArrayList<Requierment> getAllRequierments() {
		if (!mysqlConnection.isConnected())
			mysqlConnection.connect();
		if (!mysqlConnection.isConnected())
			return null;
		else
			return mysqlConnection.getAllRequierments();
	}

	//Getting all requirement from the database
	public static boolean updateRequierment(String id, String status) {
		if (!mysqlConnection.isConnected())
			mysqlConnection.connect();
		if (!mysqlConnection.isConnected())
			return false;
		else
			return mysqlConnection.updateRequierment(id, status);
	}
}
