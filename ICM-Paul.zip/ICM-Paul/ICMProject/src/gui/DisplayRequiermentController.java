package gui;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import Client.ClientConsole;
import Entity.Requierment;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class DisplayRequiermentController extends Application implements Initializable {
	private Requierment currentRequierment;

	@FXML
	private Label lblSelectedRequierment;
	@FXML
	private Label lblRequesterName;
	@FXML
	private Label lblSystemId;
	@FXML
	private Label lblCurrentStatusDescription;
	@FXML
	private Label lblTreatmentName;
	@FXML
	private Label lblStatus;

	@FXML
	private TextField txtRequesterName;
	@FXML
	private TextField txtSystemId;
	@FXML
	private TextField txtCurrentStatusDescription;
	@FXML
	private TextField txtTreatmentName;


	@FXML
	private Button btnClose;
	@FXML
	private Button btnSave;

	@FXML
	private ComboBox<String> SelectedRequierment;
	@FXML
	private ComboBox<String> SelectStatus;

	ObservableList<String> list;
	public static ArrayList<Requierment> requiermentsList;

	private int currentIndex;

	@Override
	public void start(Stage primaryStage) {
		Parent root;
		try {
			root = FXMLLoader.load(getClass().getResource("DisplayRequirementGUI.fxml"));
			Scene scene = new Scene(root);
			primaryStage.setTitle("ICM Project");
			primaryStage.setScene(scene);
			primaryStage.show();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void launchThis() {
		Application.launch();
	}

	//This function set the requirement values to the gui texts boxes
	public void loadRequierment(Requierment requierment) {
		this.currentRequierment = requierment;
		this.txtRequesterName.setText(requierment.getName());
		this.txtCurrentStatusDescription.setText(requierment.getCurrentDescription());
		this.txtSystemId.setText(requierment.getSystemId());
		this.txtTreatmentName.setText(requierment.getTreatmentBy());
		this.SelectStatus.getSelectionModel().select(requierment.getStatus());

	}

	//This function add the requirements to the combo box
	private void setRequiermentsComboBox() {
		ArrayList<String> requiermentsListIds = new ArrayList<String>();
		if (requiermentsList != null) {
			for (int i = 0; i < requiermentsList.size(); i++) {
				requiermentsListIds.add(requiermentsList.get(i).getId());
			}

			list = FXCollections.observableArrayList(requiermentsListIds);
			SelectedRequierment.setItems(list);
		}
	}
	
	//This function add the status to the combo box
	private void setStatusComboBox() {
		ArrayList<String> statusList = new ArrayList<String>();
		statusList.add("Active");
		statusList.add("Suspended");
		statusList.add("Closed");
			list = FXCollections.observableArrayList(statusList);
			SelectStatus.setItems(list);
		}
	
	
	//This function be called when the user click on save button
	//Its request from the console to update the requirements
	public void saveData(ActionEvent event) throws Exception {
		if (ClientConsole.updateRequierment(currentRequierment.getId(), this.SelectStatus.getSelectionModel().getSelectedItem()) == true) {
			currentRequierment.setStatus(this.SelectStatus.getSelectionModel().getSelectedItem());
			requiermentsList.set(currentIndex, currentRequierment);
			showMessage("Updated", "Status has been updated successfuly");
		} else {
			showMessage("Error", "Status hasn't been updated ");

		}

	}

	//Here we are initializing every thing before the app runs
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		int i = 0;
		setStatusComboBox();
		showMessage("Loading", "Please Wait, the client is trying to connect to the server\n Press ok the continue");
		loadRequierments();//call the function load requirement the sets the combo box
		while (requiermentsList == null)//here we wait the server to response and send to the client the requirement
			try {
				if (i == 10000)//the console will wait 10seconds and push error message and exit if we didnt recieve the requirements
					exitWithMessage("Error", "Time out");
				Thread.sleep(1);
				i++;
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		if (requiermentsList.size() < 1) {//if the requirement are empty  exit
			exitWithMessage("Error", "There is no components avaible");

		}
		setRequiermentsComboBox();//here we sets the combobox after receive  the requirement list
		currentIndex = 0;//index of select requierment
		loadRequierment(requiermentsList.get(0));//Loading the first requirement
		SelectedRequierment.getSelectionModel().selectFirst();
	}

	//Here we select a specific requirement from the combobox
	public void selectRequierment() {
		currentIndex = SelectedRequierment.getSelectionModel().getSelectedIndex();
		loadRequierment(requiermentsList.get(currentIndex));
	}

	//This function  request from the server to send the requirement list to the console
	public void loadRequierments() {
		try {
			ClientConsole.client.sendToServer("getAllRequirements");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	//When the user click on close the system close 
	public void closeFunc(ActionEvent event) throws Exception {
		System.exit(1);
	}

	public static void showMessage(String title, String msg) {
		JFrame frame = new JFrame(title);
		JOptionPane.showMessageDialog(frame, msg);
	}

	public static void exitWithMessage(String title, String msg) {
		JFrame frame = new JFrame(title);
		JOptionPane.showMessageDialog(frame, msg);
		System.exit(1);
	}

	//The client when receive the requirements from the server use this function to set the requirements
	public static void setRequiermentList(ArrayList<Requierment> requierments) {
		requiermentsList = requierments;
	}

}