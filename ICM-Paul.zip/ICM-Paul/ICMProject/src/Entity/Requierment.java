package Entity;

import java.util.ArrayList;

public class Requierment {

	private String id;
	private String name;
	private String systemId;
	private String currentDescription;
	private String requestedDescription;
	private String status;
	private String treatmentBy;

	public Requierment(String id, String name, String systemId, String currentDescription, String requestedDescription,
			String status, String treatmentBy) {
		this.id = id;
		this.name = name;
		this.systemId = systemId;
		this.currentDescription = currentDescription;
		this.requestedDescription = requestedDescription;
		this.status = status;
		this.treatmentBy = treatmentBy;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSystemId() {
		return systemId;
	}

	public void setSystemId(String systemId) {
		this.systemId = systemId;
	}

	public String getCurrentDescription() {
		return currentDescription;
	}

	public void setCurrentDescription(String currentDescription) {
		this.currentDescription = currentDescription;
	}

	public String getRequestedDescription() {
		return requestedDescription;
	}

	public void setRequestedDescription(String requestedDescription) {
		this.requestedDescription = requestedDescription;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getTreatmentBy() {
		return treatmentBy;
	}

	public void setTreatmentBy(String treatmentBy) {
		this.treatmentBy = treatmentBy;
	}

	//This function cast the class to array list to handle it between client and server
	public ArrayList<String> toArrayString() {
		ArrayList<String> temp = new ArrayList<String>();
		temp.add(id);
		temp.add(name);
		temp.add(systemId);
		temp.add(currentDescription);
		temp.add(requestedDescription);
		temp.add(status);
		temp.add(treatmentBy);
		return temp;
	}

	//This function cast the array list to class to handle it between client and server
	public static Requierment fromArrayToClass(ArrayList<String> list) {
		return new Requierment(list.get(0), list.get(1), list.get(2), list.get(3), list.get(4), list.get(5),
				list.get(6));
	}

	public String toString() {
		String temp = new String();
		temp = "[";
		temp += id + ",";
		temp += name + ",";
		temp += systemId + ",";
		temp += currentDescription + ",";
		temp += requestedDescription + ",";
		temp += status + ",";
		temp += treatmentBy + "]";
		return temp;
	}

}
